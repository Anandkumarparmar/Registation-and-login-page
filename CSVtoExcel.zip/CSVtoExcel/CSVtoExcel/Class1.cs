﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSVtoExcel
{
    public class ImportCSVData
    {
        public static DataTable BinddataGridView(string path, string delimiter)
        {
            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(path))
            {
                string filecontent;
                filecontent = sr.ReadLine();
                if (!string.IsNullOrEmpty(filecontent))
                {
                    if (filecontent.Contains(delimiter))
                    {
                        string[] Colarray = filecontent.Split(',');

                        foreach (string Column in Colarray)
                        {
                            dt.Columns.Add(Column);
                        }
                    }
                    else
                        MessageBox.Show("File don't contain delimiter");
                    while (sr.Peek() > 0)
                    {
                        filecontent = sr.ReadLine();
                        if (filecontent.Contains(delimiter))
                        {
                            string[] RowArray = filecontent.Split(',');
                            dt.Rows.Add(RowArray);
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
            return dt;
        }

    }

    public class ExporttoExcel
    {
        public static void ExportToExcel(DataTable dt)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "(*.xlsx)|*.xlsx";
            sfd.FilterIndex = 1;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
                ExcelApp.Application.Workbooks.Add(Type.Missing);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        ExcelApp.Cells[i + 1, j + 1] = dt.Rows[i][j];
                    }
                }
                ExcelApp.ActiveWorkbook.SaveCopyAs(sfd.FileName);
                ExcelApp.ActiveWorkbook.Saved = true;
                ExcelApp.Quit();
                MessageBox.Show("Records Successfully Exported");
            }
        }
    }
}
