﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormFileOperation
{
    public partial class Form1 : Form
    {
        public string Drive { get; set; }
        public string CurrentDirectory { get; set; }
        public Form1()
        {
            InitializeComponent();
            richTextBox1.Visible = false;
            fillCBDrives();
            CBDrives.SelectedIndex = 0;
        }

        private string path = "C:\\"; //your file path root
        private static string sub; // parent full path
        private static string old = "";
        private void fillLVFileExplorer()
        {
            LVFileExplorer.Items.Clear();
            if (Drive != "" && Drive != null)
            {
                DirectoryInfo di = new DirectoryInfo(Drive);
                foreach (DirectoryInfo directory in di.GetDirectories())
                {
                    LVFileExplorer.Items.Add(directory.ToString());
                }

            }
        }


        private void fillCBDrives()
        {
            DriveInfo[] di = DriveInfo.GetDrives();
            foreach (DriveInfo drive in di)
            {
                CBDrives.Items.Add(drive.ToString());
            }
            Drive = CBDrives.GetItemText(CBDrives.SelectedValue);
            fillLVFileExplorer();
        }

        private void LVFileExplorer_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtPath.Text = path + old+@"\" + sub + @"\" + LVFileExplorer.FocusedItem.Text;
            old = sub;
        }
        private void CBDrives_SelectedIndexChanged(object sender, EventArgs e)
        {
            richTextBox1.Visible = false;
            txtPath.Text = "";
            Drive = CBDrives.GetItemText(CBDrives.SelectedItem);
            fillLVFileExplorer();
            path = Drive;
            old = "";
            sub = "";
        }

        private void LVFileExplorer_DoubleClick(object sender, EventArgs e)
        {
            LVFileExplorer.Items.Clear();
            //FileAttributes attr = File.GetAttributes(txtPath.Text);
            if (Directory.Exists(txtPath.Text))
            {
                DirectoryInfo di = new DirectoryInfo(txtPath.Text);
                LVFileExplorer.Items.Clear();
                foreach (FileInfo file in di.GetFiles())
                {
                    LVFileExplorer.Items.Add(file.ToString());
                }
                foreach (DirectoryInfo directory in di.GetDirectories())
                {
                    LVFileExplorer.Items.Add(directory.ToString());
                }
            }
            FileInfo fi = new FileInfo(txtPath.Text);
            if (fi.Extension == ".txt")
            {
                richTextBox1.Visible = true;
                string str = txtPath.Text;
                richTextBox1.LoadFile(str, RichTextBoxStreamType.PlainText);
            }
        }

        private void LVFileExplorer_MouseClick(object sender, EventArgs e)
        {
            sub = LVFileExplorer.SelectedItems[0].Text;
        }
    }
}
