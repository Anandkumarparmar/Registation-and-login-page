﻿namespace WindowsFormFileOperation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LVFileExplorer = new System.Windows.Forms.ListView();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.CBDrives = new System.Windows.Forms.ComboBox();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // LVFileExplorer
            // 
            this.LVFileExplorer.Location = new System.Drawing.Point(12, 52);
            this.LVFileExplorer.Name = "LVFileExplorer";
            this.LVFileExplorer.Size = new System.Drawing.Size(895, 165);
            this.LVFileExplorer.TabIndex = 0;
            this.LVFileExplorer.UseCompatibleStateImageBehavior = false;
            this.LVFileExplorer.SelectedIndexChanged += new System.EventHandler(this.LVFileExplorer_SelectedIndexChanged);
            this.LVFileExplorer.DoubleClick += new System.EventHandler(this.LVFileExplorer_DoubleClick);
            this.LVFileExplorer.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LVFileExplorer_MouseClick);
            // 
            // CBDrives
            // 
            this.CBDrives.FormattingEnabled = true;
            this.CBDrives.Location = new System.Drawing.Point(12, 12);
            this.CBDrives.Name = "CBDrives";
            this.CBDrives.Size = new System.Drawing.Size(895, 21);
            this.CBDrives.TabIndex = 1;
            this.CBDrives.SelectedIndexChanged += new System.EventHandler(this.CBDrives_SelectedIndexChanged);
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(12, 223);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(895, 20);
            this.txtPath.TabIndex = 2;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(12, 52);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(895, 165);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(919, 421);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.txtPath);
            this.Controls.Add(this.CBDrives);
            this.Controls.Add(this.LVFileExplorer);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView LVFileExplorer;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ComboBox CBDrives;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

