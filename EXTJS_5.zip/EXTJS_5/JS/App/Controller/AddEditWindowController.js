﻿Ext.define('JS.App.Controller.AddEditWindowController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.viewcontroller',
    init: function () {
        this.control({
            '#': {
                'afterrender': 'onAfterRender'
            }
        })
    },
    onAfterRender: function (data) {
        var me = this;
        view = me.getView();
        debugger;
        if (view.username) {
            view.setValue(view.rec);
        }
    }
})
