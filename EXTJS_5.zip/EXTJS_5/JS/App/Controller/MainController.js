﻿Ext.define('Js.App.Controller.MainController', {
    extend: 'Ext.app.ViewController',
    requires: ['JS.App.View.Annoucement.AnnoucementMessage'],
    alias: 'controller.maincontroller',
    init: function () {
        this.control({
            '#': {
                'afterrender':'onAfterRender'
            }
        })
    },
    onAfterRender: function ()
    {
        Ext.create('JS.App.View.Annoucement.AnnoucementMessage', {}).show();
    }
})