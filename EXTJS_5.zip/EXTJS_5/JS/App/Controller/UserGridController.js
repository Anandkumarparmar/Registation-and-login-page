﻿Ext.define('JS.App.Controller.UserGridController', {
    extend: 'Ext.app.ViewController',
    requires: ['App.View.UserManage.AddEditWindow2', 'JS.App.View.Annoucement.AnnoucementMessage'],
    alias: 'controller.usergridcontroller',
    init: function () {
        this.control({
            '#': {
                //'afterrender': 'onAfterRender'
            }
        })
    },
    onAfterRender: function () {
     
    },
    onEditWindow: function (User) {
        debugger;
        var me = this;
        Ext.create('App.View.UserManage.AddEditWindow2', {
            rec: User,
            username: User.name,
            listeners: {
                edit: function (data) {
                    alert(data.email);
                }
            }
        }).show();
    }
})