﻿Ext.define('JS.App.View.Annoucement.AnnoucementMessage', {
    extend: 'Ext.window.Window',
    height: '20%',
    width: '20%',
    title: 'Annoucement',
    scrollable: 'y',
    defaultAlign: 'br-br',
    initComponent: function () {
        var me = this;
        var gridp;
        Ext.define('myStore', {
            extend: 'Ext.data.Store',
            alias: 'store.mystore',
            data: [
                { 'UserName': '1 ' + sessionStorage.getItem("UserName") },
                { 'UserName': '2 Prakash' },
                 { 'UserName': '3 Prakash' },
                  { 'UserName': '4 Prakash' },
                   { 'UserName': '5 Prakash' },
            ]
        }),
        gridp = Ext.create('Ext.grid.Panel', {
            forceFit: true,
            sortableColumns: false,
            store: {
                type: 'mystore',
                autoLoad: true
            },
            columns: [
            { dataIndex: 'UserName' },
            ]
        })
        me.items = [
            {
                xtype: gridp
            }
        ]
        me.callParent(arguments);
    }
})