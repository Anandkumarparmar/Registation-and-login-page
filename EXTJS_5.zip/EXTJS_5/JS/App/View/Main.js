﻿Ext.define('App.View.Main', {
    extend: 'Ext.container.Viewport',
    requires: ['App.View.UserManage.UserGrid', 'App.View.UserManage.Login', 'Js.App.Controller.MainController'],
    controller: 'maincontroller',
    layout: 'border',
    width: '100%',
    height: '100%',
    id: 'Main',
    title: 'Main',
    afterrender: function () {
        Ext.create('JS.App.View.Annoucement.AnnoucementMessage', {

        }).show();
    },
    initComponent: function () {

        var me = this;
        var flag;
        me.items = [
            {
                xtype: 'panel',
                region: 'north',
                width: '100%',
                items: [{
                    xtype: 'toolbar',
                    items: [
                        {
                            xtype: 'button',
                            text: 'Knovos'
                        }, '->',
                        {
                            xtype: 'splitbutton',
                            text: 'pmanand29@',
                            menu: {
                                items: [
                                    {
                                        xtype: 'displayfield',
                                        fieldLabel: 'Anand Parmar'
                                    },
                                    {
                                        xtype: 'button',
                                        text: 'Logout'
                                    }
                                ]
                            }
                        }
                    ]
                }]
            },
            {
                region: 'center',
                xtype: 'usergrid',
                itemId: 'pnlMain',
                width: '100%',
                height: '100%',
            },
            {
                region: 'west',
                xtype: 'panel',
                width: '7%',
                height: '100%',
                items: [
                    {
                        xtype: 'button',
                        text: 'Grid Panel',
                        handler: function () {
                            changePath('usergrid');
                        }
                    },
                    {
                        xtype: 'button',
                        text: 'Log in',
                        handler: function () {
                            changePath('login');
                        }
                    },
                ],

            },
            changePath = function (path) {
                if (flag != path) {
                    var pnlmain = me.down("#pnlMain");
                    var main = Ext.getCmp("Main");
                    Ext.getCmp("Main").remove(pnlmain);
                    Ext.getCmp("Main").remove(main);
                    var newpanel = ('Ext.panel.Panel', {
                        xtype: path,
                        itemId: 'pnlMain'
                    })
                    flag = path;
                    Ext.getCmp("Main").add(newpanel);
                }
            }
        ]

        me.callParent(arguments);
    },

});