﻿Ext.define('App.View.UserManage.UserGrid', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.usergrid',
    forceFit:true,
    requires: ['App.View.UserManage.AddEditWindow2', 'JS.App.Controller.UserGridController'],
    controller: 'usergridcontroller',
    initComponent: function () {

        var me = this;
        Ext.define('Fiddle.store.Simpsons', {
            extend: 'Ext.data.Store',
            alias: 'store.simpsonsstore',

            //fields: ['Islocked', 'IsActive', 'name', 'email', 'phone'],
            data: [
                { 'Islocked': 'false', 'IsActive': 'true', 'name': 'Anand', 'email': '1@gm.com', 'phone': '9374006061' },
                { 'Islocked': 'false', 'IsActive': 'false', 'name': 'Prakash', 'email': '2@gm.com', 'phone': '7374006061' },
                { 'Islocked': 'true', 'IsActive': 'true', 'name': 'Rajesh', 'email': '3@gm.com', 'phone': '9874006061' },
                { 'Islocked': 'true', 'IsActive': 'false', 'name': 'Rakesh', 'email': '4@gm.com', 'phone': '9774006061' },
            ]
        });

        var gridp = Ext.create('Ext.grid.Panel', {
            title: 'Grid Example',
            store: {
                type: 'simpsonsstore',
                autoLoad: true
            },
           
            columns: [
                {
                    xtype: 'actioncolumn',
                    header: 'Edit',
                    icon: '../images/bullet.png',
                    handler: function (grid, rowIndex, colIndex, item, e, record) {
                        me.getController().onEditWindow(record.data);
                    }
                },
                {
                    xtype: 'actioncolumn',
                    dataIndex: 'Islocked',
                    header: 'Lock/Unlock',
                    getClass: function (value) {
                        if (value == "true") {
                            return 'locked'
                        }
                    }
                },
                {
                    xtype: 'actioncolumn',
                    dataIndex: 'IsActive',
                    header: 'Active',
                    iconCls: 'active',
                    getClass: function (value) {
                        if (value == "true") {
                            return 'deactive'
                        }
                    },
                    handler: function (grid, rowIndex, ColIndex, item) {
                        alert(rowIndex);
                    }
                },
                { text: 'Name', dataIndex: 'name' },
                { text: 'Email', dataIndex: 'email', flex: 1 },
                { text: 'Phone', dataIndex: 'phone' }
            ],
            height: 200,
            width: 600,
        }
        );
        me.items = [
        {
            xtype: gridp
        }]
        me.tbar = [
            {
                xtype: 'button',
                text: 'Add User',
                width:'5%',
                handler: function () {
                    Ext.create('App.View.UserManage.AddEditWindow2', {

                    }).show();
                }
            }
        ]
        me.callParent(arguments);
    }
})