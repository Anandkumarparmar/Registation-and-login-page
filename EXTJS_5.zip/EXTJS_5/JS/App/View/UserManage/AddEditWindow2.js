﻿Ext.define('App.View.UserManage.AddEditWindow2', {
    extend: 'Ext.window.Window',
    requires: ['JS.App.Controller.AddEditWindowController'],
    controller: 'viewcontroller',
    height: '25%',
    width: '25%',
    initComponent: function () {
        var me = this;
        me.items = [
            {
                margin: "10 0 10 0",
                xtype: 'textfield',
                id: 'txtName',
                fieldLabel: 'First Name'
            },
         {
             xtype: 'textfield',
             id: 'txtEmail',
             fieldLabel: 'Email'
         },
        {
            xtype: 'textfield',
            id: 'txtPhone',
            fieldLabel: 'Phone'
        },
        ]
        me.bbar = ['->', {
            xtype: 'button',
            text: 'Submit',
            handler: function () {
                me.close();
            }
        },
        {
            xtype: 'button',
            text: 'Close',
            handler: function () {
                me.close();
            }
        }]
        me.callParent(arguments);
        me._Name = me.down('#txtName');
        me._Email = me.down('#txtEmail');
        me._Phone = me.down('#txtPhone');
    },
    setValue: function (User) {
        debugger;
        var me = this;
        me._Name.setValue(User.name);
        me._Email.setValue(User.email);
        me._Phone.setValue(User.phone);
    },
    getValue: function () {
        var data = {};
        var me = this;
        data.name = me._Name.value;
        data.email = me._Email.value;
        data.phone = me._Phone.value;
        return data;
    }
})