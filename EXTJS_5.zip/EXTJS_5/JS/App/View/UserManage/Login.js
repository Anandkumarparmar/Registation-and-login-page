﻿Ext.define('App.View.UserManage.Login', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.login',
    layout: 'form',

    initComponent: function () {
        var me = this;
        me.items = [
        {
            xtype: 'panel',
            region: 'center',
            width: 400,
            plain: true,
            items: [
                {
                    xtype: 'textfield',
                    fieldLabel: 'Enter email Id',
                    itemId:'txtEmail'
                },
                {
                    xtype: 'textfield',
                    fieldLabel: 'Enter Password',
                    itemId:'txtPass'
                },
                {
                    xtype: 'button',
                    text: 'Log In',
                    handler: function () {
                        var username = me.down("#txtEmail");
                        var password = me.down("#txtPass");
                        var myparams = { "Username": username.value, "Password": password.value };

                        Ext.Ajax.request({
                            url: ' http://localhost:54054/Service1.svc?wsdl',
                            params: Ext.encode(myparams),
                            method: 'POST',
                            headers: this.header || { 'Content-Type': 'application/json;charset=utf-8' },
                            success: function (response, options) {
                                var s = response.responseText;
                                Ext.MessageBox.alert('Success', s);

                            },
                            failure: function (response, options) {
                                Ext.MessageBox.alert('Failed', 'Unable to get');
                            }
                        })
                    }
                }
            ]
        }]
        me.callParent(arguments);
    }

})