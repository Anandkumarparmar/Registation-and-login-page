﻿Ext.define('App.View.UserManage.Registration', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.registration',
    layout: 'form',

    initComponent: function () {
        var me = this;
        me.items = [
        {
            xtype: 'form',
            region: 'center',
            id: 'regform',
            width: 400,
            plain: true,
            defaults: {
                xtype: 'textfield',
                allowBlank: false
            },
            items: [
                {
                    fieldLabel: 'Enter your name',

                },
                {
                    fieldLabel: 'Enter email Id'
                },
                {
                    fieldLabel: 'Enter Password'
                },
                {
                    xtype: 'button',
                    text: 'SignUp',
                    handler: function () {
                        var form = Ext.getCmp('regform');
                        if (form.isValid()) {
                            Ext.Msg.alert('hello', "Form is valid");
                        }
                    }
                }
            ]
        }]
        me.callParent(arguments);
    }

})