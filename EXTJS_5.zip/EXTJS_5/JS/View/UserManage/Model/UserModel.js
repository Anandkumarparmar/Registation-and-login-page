﻿Ext.define('Mymodel', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'Id', type: 'int' },
        { name: 'username', type: 'string' },
        {name:'lastname',type:'string'}
    ]
})