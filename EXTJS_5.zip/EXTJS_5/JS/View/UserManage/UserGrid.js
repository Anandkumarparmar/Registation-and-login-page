﻿Ext.define('mywindow',
{
    extend: 'Ext.window.Window',
    alias: 'widget.userlist',
    title: 'Edit',
    items: [
    {
        xtype: 'textfield',
        id: 'txtName',
        fieldLabel: 'Name'
    },
    {
        xtype: 'textfield',
        id: 'txtEmail',
        fieldLabel: 'Email'
    },
    {
        xtype: 'textfield',
        id: 'txtPhone',
        fieldLabel: 'Phone'
    },
    {
        xtype: 'button',
        text: 'Submit'
    }
    ],
    width: 600,
    height: 200
});
Ext.define('App.View.Main.UserManage.UserGrid', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.usergrid',

    initComponent: function () {

        var me = this;
        Ext.define('Fiddle.store.Simpsons', {
            extend: 'Ext.data.Store',
            alias: 'store.simpsonsstore',

            //fields: ['Islocked', 'IsActive', 'name', 'email', 'phone'],
            data: [
                { 'Islocked': 'false', 'IsActive': 'true', 'name': 'Anand', 'email': '1@gm.com', 'phone': '9374006061' },
                { 'Islocked': 'false', 'IsActive': 'false', 'name': 'Prakash', 'email': '2@gm.com', 'phone': '7374006061' },
                { 'Islocked': 'true', 'IsActive': 'true', 'name': 'Rajesh', 'email': '3@gm.com', 'phone': '9874006061' },
                { 'Islocked': 'true', 'IsActive': 'false', 'name': 'Rakesh', 'email': '4@gm.com', 'phone': '9774006061' },
            ]
        });

        var gridp = Ext.create('Ext.grid.Panel', {
            title: 'Grid Example',
            store: {
                type: 'simpsonsstore',
                autoLoad: true
            },
           
            columns: [
                {
                    xtype: 'actioncolumn',
                    header: 'Edit',
                    icon: '../images/bullet.png',
                    handler: function (grid, rowIndex, colIndex, item, e, record) {
                        var thewindow = Ext.widget('userlist');
                        Ext.getCmp('txtName').setValue(record.data.name);
                        Ext.getCmp('txtEmail').setValue(record.data.email).readOnly = true;
                        Ext.getCmp('txtPhone').setValue(record.data.phone);
                        thewindow.show();
                    }
                },
                {
                    xtype: 'actioncolumn',
                    dataIndex: 'Islocked',
                    header: 'Lock/Unlock',
                    getClass: function (value) {
                        if (value == "true") {
                            return 'locked'
                        }
                    }
                },
                {
                    xtype: 'actioncolumn',
                    dataIndex: 'IsActive',
                    header: 'Active',
                    iconCls: 'active',
                    getClass: function (value) {
                        if (value == "true") {
                            return 'deactive'
                        }
                    },
                    handler: function (grid, rowIndex, ColIndex, item) {
                        alert(rowIndex);
                    }
                },
                { text: 'Name', dataIndex: 'name' },
                { text: 'Email', dataIndex: 'email', flex: 1 },
                { text: 'Phone', dataIndex: 'phone' }
            ],
            height: 200,
            width: 600,
        }
        );
        me.items = [
        {
            xtype: gridp
        }]
        me.tbar = [
            {
                xtype: 'button',
                text: 'Add User',
                handler: function () {
                    
                }
            }
        ]
        me.callParent(arguments);
    }
})