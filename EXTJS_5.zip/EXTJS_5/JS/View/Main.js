﻿Ext.define('App.View.Main', {
    extend: 'Ext.container.Viewport',
    requires: ['App.View.Main.UserManage.UserGrid', 'App.View.Main.UserManage.Login'],
    layout: 'border',
    width: '100%',
    height: '100%',
    id: 'Main',
    title: 'Main',

    initComponent: function () {
        var me = this;
        me.items = [

            {
                region: 'center',
                xtype: 'usergrid',
                itemId: 'pnlMain',
                width: '100%',
                height: '100%',
            },
            {
                region: 'west',
                xtype: 'panel',
                width: '7%',
                height: '100%',
                items: [
                    {
                        xtype: 'button',
                        text: 'Grid Panel',
                        handler: function () {
                            var panmain = me.down("#pnlMain");
                            var main = Ext.getCmp("Main");
                            Ext.getCmp("Main").remove(panmain);
                            Ext.getCmp("Main").remove(main);
                            var newpanel = ('Ext.panel.Panel', {
                                xtype: 'usergrid',
                                itemId: 'pnlMain'
                            })
                            Ext.getCmp("Main").add(newpanel);
                        }
                    },
                    {
                        xtype: 'button',
                        text: 'Log in',
                        handler: function () {
                            var pnlmain = me.down("#pnlMain");
                            var main = Ext.getCmp("Main");
                            Ext.getCmp("Main").remove(pnlmain);
                            Ext.getCmp("Main").remove(main);
                            var newpanel = ('Ext.panel.Panel', {
                                xtype: 'login',
                                itemId: 'pnlMain'
                            })
                            Ext.getCmp("Main").add(newpanel);
                        }
                    },
                ],
            },

        ];
        me.callParent(arguments);
    },
});