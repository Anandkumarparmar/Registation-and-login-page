﻿Ext.application({
    name: 'App',
    appfolder: '/35/App',
    launch: function () {
        var mainView = Ext.create('App.View.Main')
    }
});