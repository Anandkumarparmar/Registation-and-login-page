﻿Ext.define('JS.BorderLayout', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.borderLayout',
    layout: 'border',
    initComponent: function () {
        var me = this;
        me.items = [
        {
            xtype: 'panel',
            height: '25%',
            width:'25%',
            region: 'north',
            items: [{
                xtype: 'button',
                text:'hello'
            }]
        }
];
me.callParent(arguments);
}
});