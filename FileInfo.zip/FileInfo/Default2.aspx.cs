﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillDropdownList();
        }
    }

    private void FillListView(string path)
    {
        if (path != "")
        {
            ListBox1.Items.Clear();
            DirectoryInfo di = new DirectoryInfo(path);
            if (DropDownList1.SelectedItem.Text == "Select" || DropDownList1.SelectedItem.Text == "D:\\")
            {
                ListBox1.Items.Add("Please select only Drive");
            }
            else
            {
                FileInfo[] files = di.GetFiles();
                DirectoryInfo[] directories = di.GetDirectories();
                foreach (DirectoryInfo item in directories)
                {
                    ListBox1.Items.Add(item.ToString());
                }
                foreach (FileInfo file in files)
                {
                    ListBox1.Items.Add(file.Name);
                }
            }
        }
        else
        {
            ListBox1.Items.Clear();
            DirectoryInfo di = new DirectoryInfo(DropDownList1.SelectedItem.Text);
            if (DropDownList1.SelectedItem.Text == "Select" || DropDownList1.SelectedItem.Text == "D:\\")
            {
                ListBox1.Items.Add("Please select only Drive");
            }
            else
            {
                FileInfo[] files = di.GetFiles();
                DirectoryInfo[] directories = di.GetDirectories();
                foreach (DirectoryInfo item in directories)
                {
                    ListBox1.Items.Add(item.ToString());
                }
                foreach (FileInfo file in files)
                {
                    ListBox1.Items.Add(file.Name);
                }
            }
        }
    }

    private void fillDropdownList()
    {
        DropDownList1.DataSource = System.IO.DriveInfo.GetDrives();
        DropDownList1.DataBind();
        DropDownList1.Items.Insert(0, "Select");
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string path = "";
        FillListView(path);
    }

    protected void DropDownList1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string str = "";
        str += DropDownList1.SelectedValue + ListBox1.SelectedValue;
        FillListView(str);
    }

    protected void btnADD_Click(object sender, EventArgs e)
    {
       
    }
}