﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;
using AjaxControlToolkit;

public partial class Homepage : System.Web.UI.Page
{
    SqlConnection sqlcon;
    SqlDataAdapter sqladp;
    DataTable dt;
    private static string Drives;
    private static string directory;
    private static string path = "";
    private static int Filecount = 0;
    private static int directorycount = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        sqlcon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\TNet8\source\WebSites\FileInfo\App_Data\FileInfo_Db.mdf;Integrated Security=True");
        if (!IsPostBack)
        {
            Drives = "c:\\";
            fillListView();
            fillDLDrives();
            fillDLDirectories();
            fillLBFiles();
        }

    }

    private void fillLBFiles()
    {
        LBFiles.Items.Clear();
        if (path == null || path == "")
        {
            path = "C:\\";
        }
        DirectoryInfo di = new DirectoryInfo(path);
        foreach (FileInfo file in di.GetFiles())
        {
            LBFiles.Items.Add(file.ToString());
        }
    }

    private void fillDLDirectories()
    {

        DLDirectories.Items.Clear();
        DirectoryInfo di = new DirectoryInfo(Drives);
        foreach (DirectoryInfo directory in di.GetDirectories())
        {
            DLDirectories.Items.Add(directory.ToString());
        }
        fillLBFiles();
    }

    private void fillDLDrives()
    {
        path = "";
        DriveInfo[] di = DriveInfo.GetDrives();
        foreach (DriveInfo drive in di)
        {
            if (drive.ToString() == @"D:\")
            {
                continue;
            }
            DLDrives.Items.Add(drive.ToString());
        }
        Drives = DLDrives.SelectedItem.Text;
        fillLBFiles();
    }

    private void fillListView()
    {
        sqlcon.Open();
        sqladp = new SqlDataAdapter("select img, path,filename from tblFileInfo", sqlcon);
        dt = new DataTable();
        sqladp.Fill(dt);
        sqlcon.Close();
        ListView1.DataSource = dt;
        ListView1.DataBind();
    }


    protected void btnFileInfo_Click(object sender, EventArgs e)
    {
        int wordcount = 0;
        string delim = " ,."; //maybe some more delimiters like ?! and so on
        string[] fields = null;
        string line = null;
        string creator;
        long charactercount;
        var btn = (Button)sender;
        var item = (ListViewItem)btn.NamingContainer;
        Label lblpath = (Label)item.FindControl("lblpath");
        AjaxControlToolkit.ModalPopupExtender modalPopup = (AjaxControlToolkit.ModalPopupExtender)item.FindControl("ModelMetadataPopup");

        FileInfo fi = new FileInfo(lblpath.Text);

        creator = File.GetAccessControl(lblpath.Text).GetOwner(typeof(System.Security.Principal.NTAccount)).ToString();
        DateTime lastModified = fi.LastWriteTime;
        DateTime creation = fi.CreationTime;
        int lineCount = File.ReadAllLines(lblpath.Text).Length;
        charactercount = fi.Length;

        StreamReader sr = new StreamReader(lblpath.Text);
        while (!sr.EndOfStream)
        {
            line = sr.ReadLine();
            line.Trim();
            fields = line.Split(delim.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            wordcount += fields.Length;
        }

        string mimeType = MimeMapping.GetMimeMapping(lblpath.Text);

        sqlcon.Open();
        SqlCommand cmd = new SqlCommand("Sp_insert", sqlcon);
        cmd.Parameters.AddWithValue("@path", lblpath.Text);
        cmd.Parameters.AddWithValue("@creator", creator);
        cmd.Parameters.AddWithValue("@lastupdatedate", lastModified);
        cmd.Parameters.AddWithValue("@createddate", creation);
        cmd.Parameters.AddWithValue("@wordcount", wordcount);
        cmd.Parameters.AddWithValue("@linecount", lineCount);
        cmd.Parameters.AddWithValue("@mimetype", mimeType);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        sqlcon.Close();


        sqlcon.Open();
        SqlDataAdapter sdp = new SqlDataAdapter("select * from tblFileInfo where path='" + lblpath.Text + "'", sqlcon);
        dt = new DataTable();
        sdp.Fill(dt);
        LVFileInfo.DataSource = dt;
        LVFileInfo.DataBind();
        sqlcon.Close();

        modalPopup.TargetControlID = "btnFileInfo";
        modalPopup.Show();
    }


    protected void IBFileOpen_Click(object sender, ImageClickEventArgs e)
    {
        var btn = (ImageButton)sender;
        var item = (ListViewItem)btn.NamingContainer;
        Label lblpath = (Label)item.FindControl("lblpath");
        System.Diagnostics.Process.Start(lblpath.Text);
    }

    protected void DLDrives_SelectedIndexChanged(object sender, EventArgs e)
    {
        path = DLDrives.SelectedItem.Text;
        Drives = DLDrives.SelectedItem.Text;
        TextBox1.Text = "";
        fillDLDirectories();
        fillLBFiles();
    }

    protected void btnADD_Click(object sender, EventArgs e)
    {

        string fileimage = "";
        FileInfo fi = new FileInfo(path);
        if (fi.Extension == ".txt")
        {
            fileimage = "txtimage.jpg";
        }
        else if (fi.Extension == ".pdf")
        {
            fileimage = "pdfimage.jpg";
        }
        else if (fi.Extension == ".aspx")
        {
            fileimage = "aspximage.jpg";
        }
        else if (fi.Extension == ".config")
        {
            fileimage = "configimage.jpg";
        }
        else if (fi.Extension == ".jpg")
        {
            fileimage = "jpegimage.jpg";
        }
        else if (fi.Extension == ".html")
        {
            fileimage = "htmlimage.jpg";
        }
        else
        {
            fileimage = "document.png";
        }
            sqlcon.Open();
        SqlCommand sqlcmd = new SqlCommand("insert into tblFileInfo (img,path,filename) values('" + fileimage + "','" + path + "','" + fi.Name + "')", sqlcon);
        sqlcmd.ExecuteNonQuery();
        sqlcon.Close();
        fillListView();
    }

    protected void LBFiles_SelectedIndexChanged(object sender, EventArgs e)
    {
        Filecount++;
        if (Filecount > 1)
        {
            path = Drives + directory;
        }
        path += "\\" + LBFiles.SelectedItem.Text;
        TextBox1.Text = path;

    }

    protected void DLDirectories_SelectedIndexChanged(object sender, EventArgs e)
    {
        directorycount++;
        {
            if (directorycount > 1)
            {
                path = Drives;
            }
        }
        path += DLDirectories.SelectedItem.Text;
        directory = DLDirectories.SelectedItem.Text;
        fillLBFiles();
    }

    protected void btnRemove_Click(object sender, EventArgs e)
    {
        sqlcon.Open();
        var btn = (Button)sender;
        var item = (ListViewItem)btn.NamingContainer;
        Label lblpath = (Label)item.FindControl("lblpath");
        SqlCommand cmd = new SqlCommand("delete from tblFileInfo where path='" + lblpath.Text + "'", sqlcon);
        cmd.ExecuteNonQuery();
        sqlcon.Close();
        fillListView();
    }

    protected void ListView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}