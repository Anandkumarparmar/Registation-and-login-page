﻿namespace CSVtoGridView
{
    partial class CSVform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblPath = new System.Windows.Forms.Label();
            this.buttonFileLoad = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.buttonFileUpdate = new System.Windows.Forms.Button();
            this.buttonExportExcel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Tomato;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(22, 16);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(5);
            this.label1.Size = new System.Drawing.Size(56, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Path :";
            // 
            // lblPath
            // 
            this.lblPath.AutoSize = true;
            this.lblPath.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPath.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPath.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPath.Location = new System.Drawing.Point(113, 18);
            this.lblPath.Name = "lblPath";
            this.lblPath.Padding = new System.Windows.Forms.Padding(5);
            this.lblPath.Size = new System.Drawing.Size(10, 28);
            this.lblPath.TabIndex = 1;
            // 
            // buttonFileLoad
            // 
            this.buttonFileLoad.BackColor = System.Drawing.Color.DarkGreen;
            this.buttonFileLoad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonFileLoad.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.buttonFileLoad.FlatAppearance.BorderSize = 0;
            this.buttonFileLoad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.buttonFileLoad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.buttonFileLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFileLoad.ForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.buttonFileLoad.Location = new System.Drawing.Point(468, 11);
            this.buttonFileLoad.Name = "buttonFileLoad";
            this.buttonFileLoad.Size = new System.Drawing.Size(75, 31);
            this.buttonFileLoad.TabIndex = 2;
            this.buttonFileLoad.Text = "File Load";
            this.buttonFileLoad.UseVisualStyleBackColor = false;
            this.buttonFileLoad.Click += new System.EventHandler(this.buttonFileLoad_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.Teal;
            this.dataGridView1.Location = new System.Drawing.Point(25, 63);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(518, 160);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // buttonFileUpdate
            // 
            this.buttonFileUpdate.BackColor = System.Drawing.Color.ForestGreen;
            this.buttonFileUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonFileUpdate.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.buttonFileUpdate.FlatAppearance.BorderSize = 0;
            this.buttonFileUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.buttonFileUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.buttonFileUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFileUpdate.ForeColor = System.Drawing.Color.White;
            this.buttonFileUpdate.Location = new System.Drawing.Point(468, 390);
            this.buttonFileUpdate.Name = "buttonFileUpdate";
            this.buttonFileUpdate.Size = new System.Drawing.Size(75, 31);
            this.buttonFileUpdate.TabIndex = 4;
            this.buttonFileUpdate.Text = "Update File";
            this.buttonFileUpdate.UseVisualStyleBackColor = false;
            this.buttonFileUpdate.Click += new System.EventHandler(this.buttonFileUpdate_Click);
            // 
            // buttonExportExcel
            // 
            this.buttonExportExcel.BackColor = System.Drawing.Color.Green;
            this.buttonExportExcel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExportExcel.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.buttonExportExcel.FlatAppearance.BorderSize = 0;
            this.buttonExportExcel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.buttonExportExcel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.buttonExportExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExportExcel.ForeColor = System.Drawing.Color.LightYellow;
            this.buttonExportExcel.Location = new System.Drawing.Point(436, 238);
            this.buttonExportExcel.Name = "buttonExportExcel";
            this.buttonExportExcel.Size = new System.Drawing.Size(107, 31);
            this.buttonExportExcel.TabIndex = 5;
            this.buttonExportExcel.Text = "Export To Excel";
            this.buttonExportExcel.UseVisualStyleBackColor = false;
            this.buttonExportExcel.Click += new System.EventHandler(this.buttonExportExcel_Click);
            // 
            // CSVform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 433);
            this.Controls.Add(this.buttonExportExcel);
            this.Controls.Add(this.buttonFileUpdate);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonFileLoad);
            this.Controls.Add(this.lblPath);
            this.Controls.Add(this.label1);
            this.Name = "CSVform";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPath;
        private System.Windows.Forms.Button buttonFileLoad;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button buttonFileUpdate;
        private System.Windows.Forms.Button buttonExportExcel;
    }
}

