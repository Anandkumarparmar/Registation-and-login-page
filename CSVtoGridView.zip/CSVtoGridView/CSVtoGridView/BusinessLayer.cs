﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVtoGridView
{
    class BusinessLayer
    {
        public DataTable BinddataGridView(string path)
        {
            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(path))
            {
                string filecontent;
                filecontent = sr.ReadLine();
                if (!string.IsNullOrEmpty(filecontent))
                {
                    string[] Colarray = filecontent.Split(',');
                    
                    foreach (string Column in Colarray)
                    {
                        dt.Columns.Add(Column);
                    }

                    while (sr.Peek() > 0)
                    {
                        filecontent = sr.ReadLine();
                        string[] RowArray = filecontent.Split(',');
                        dt.Rows.Add(RowArray);
                    }
                }
            }
            return dt;
        }
    }
}
