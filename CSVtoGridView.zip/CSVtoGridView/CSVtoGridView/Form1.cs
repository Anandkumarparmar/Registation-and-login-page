﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CSVtoGridView
{
    public partial class CSVform : Form
    {
        public CSVform()
        {
            InitializeComponent();
        }

        private void buttonFileLoad_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                lblPath.Text = openFileDialog1.FileName;
                BinddataGridView();
            }
        }

        private void BinddataGridView()
        {
            using (StreamReader sr = new StreamReader(lblPath.Text))
            {
                string filecontent;
                filecontent = sr.ReadLine();
                if (!string.IsNullOrEmpty(filecontent))
                {
                    string[] Colarray = filecontent.Split(',');
                    DataTable dt = new DataTable();
                    foreach (string Column in Colarray)
                    {
                        dt.Columns.Add(Column);
                    }

                    while (sr.Peek() > 0)
                    {
                        filecontent = sr.ReadLine();
                        string[] RowArray = filecontent.Split(',');
                        dt.Rows.Add(RowArray);
                    }
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void buttonFileUpdate_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            foreach (DataGridViewColumn dcol in dataGridView1.Columns)
            {
                dt.Columns.Add(dcol.Name);
            }
            dt.Rows.Add();
            int i = 0;
            foreach (Control txt in Controls)
            {
                if (txt.GetType() == typeof(TextBox))
                {
                    dt.Rows[0][i] = txt.Text;
                    i++;
                }
            }
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            for (int i = 0, j = 280; i < dataGridView1.ColumnCount; i++, j = j + 30)
            {
                TextBox txtBox = new TextBox();
                Label lbl = new Label();
                lbl.Location = new System.Drawing.Point(50, j);
                lbl.Text = dataGridView1.Columns[i].HeaderText;
                txtBox.Location = new System.Drawing.Point(150, j);
                txtBox.Size = new System.Drawing.Size(80, 350);
                txtBox.Text = dataGridView1.Rows[0].Cells[i].Value.ToString();
                Controls.Add(txtBox);
                Controls.Add(lbl);
            }
        }
    }
}
