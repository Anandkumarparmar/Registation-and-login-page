﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CSVtoGridView
{
    public partial class CSVform : Form
    {
        BusinessLayer BL = new BusinessLayer();
        public CSVform()
        {
            InitializeComponent();
        }
        string filename;
        private void buttonFileLoad_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                lblPath.Text = openFileDialog1.FileName;
                filename = openFileDialog1.SafeFileName;
                dataGridView1.DataSource = BL.BinddataGridView(lblPath.Text);
            }
        }

        private void buttonFileUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataTable dt = new DataTable();
                string csv = "";
                foreach (DataGridViewColumn dcol in dataGridView1.Columns)
                {
                    dt.Columns.Add(dcol.Name);
                }
                dt.Rows.Add();
                int i = 0;
                foreach (Control txt in Controls)
                {
                    if (txt.GetType() == typeof(TextBox))
                    {
                        dataGridView1.SelectedRows[0].Cells[i].Value = txt.Text;
                        //dt.Rows[0][i] = txt.Text;
                        i++;
                    }
                }
                //dataGridView1.DataSource = dt;

                foreach (DataGridViewColumn dcol in dataGridView1.Columns)
                {
                    if (dcol.Index == dataGridView1.ColumnCount - 1)
                        csv += dcol.HeaderText;
                    else
                        csv += dcol.HeaderText + ',';
                }
                csv += "\r\n";
                for (int j = 0; j < dataGridView1.Rows.Count; j++)
                {
                    for (int k = 0; k < dataGridView1.Rows[j].Cells.Count; k++)
                    {
                        if (k == dataGridView1.Rows[j].Cells.Count - 1)
                            csv += dataGridView1.Rows[j].Cells[k].Value.ToString();
                        else
                            csv += dataGridView1.Rows[j].Cells[k].Value.ToString() + ',';
                    }
                    csv += "\r\n";
                }
                File.WriteAllText(lblPath.Text, csv);
                dataGridView1.DataSource = BL.BinddataGridView(lblPath.Text);
                buttonExportExcel_Click(sender, e);
                MessageBox.Show("Data Updated Successfully");
            }
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            for (int i = 0, j = 280; i < dataGridView1.ColumnCount; i++, j = j + 30)
            {
                TextBox txtBox = new TextBox();
                Label lbl = new Label();
                lbl.Location = new System.Drawing.Point(50, j);
                lbl.Text = dataGridView1.Columns[i].HeaderText;
                txtBox.Location = new System.Drawing.Point(150, j);
                txtBox.Size = new System.Drawing.Size(80, 350);
                txtBox.Text = dataGridView1.SelectedRows[0].Cells[i].Value.ToString();
                Controls.Add(txtBox);
                Controls.Add(lbl);
            }
        }

        private void buttonExportExcel_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            worksheet.Name = "Exported from dataGridview";
            for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
            }
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                }
            }
            int index = filename.IndexOf('.');
            string file = filename.Substring(0, index) + ".xlsx";

            workbook.SaveAs("E:\\Anand\\Excel\\" + file, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                                              Type.Missing, Type.Missing, Type.Missing, Type.Missing);
        }
    }
}
