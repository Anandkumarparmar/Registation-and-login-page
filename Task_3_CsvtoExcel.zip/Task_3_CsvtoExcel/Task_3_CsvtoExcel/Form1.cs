﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CSVtoExcel;
using System.IO;

namespace Task_3_CsvtoExcel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Control> RemoveControlList = new List<Control>();
        string dynamicId = "";
        private void buttonFileLoad_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = CSVtoExcel.ImportCSVData.BinddataGridView(lblPath.Text, comboBox1.SelectedItem.ToString());
                if (dataGridView1.Rows.Count > 0)
                    buttonExportExcel.Visible = true;
                dynamicControlAdd();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
            
        }

        private void dynamicControlAdd()
        {
            foreach (Control singleControl in panelRight.Controls)
            {
                if (singleControl.GetType() != typeof(Button))
                    RemoveControlList.Add(singleControl);
            }
            foreach (Control control in RemoveControlList)
            {
                panelRight.Controls.Remove(control);
            }
            if (dataGridView1.SelectedRows.Count > 0)
            {
                for (int i = 0, j = 10; i < dataGridView1.ColumnCount; i++, j = j + 30)
                {
                    TextBox txtBox = new TextBox();
                    txtBox.Location = new System.Drawing.Point(150, j);
                    txtBox.Size = new System.Drawing.Size(80, 350);
                    txtBox.Text = dataGridView1.SelectedRows[0].Cells[i].Value.ToString();
                    txtBox.Name = "dynamicTextBox" + i;

                    Label lbl = new Label();
                    lbl.Location = new System.Drawing.Point(50, j);
                    lbl.Text = dataGridView1.Columns[i].HeaderText;
                    lbl.Name = "dynamicLabel" + i;
                    lbl.ForeColor = Color.White;

                    panelRight.Controls.Add(txtBox);
                    panelRight.Controls.Add(lbl);
                }
                panelRight.Visible = true;
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you Want to EXIT ?","",MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                dynamicControlAdd();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void buttonFileUpdate_Click(object sender, EventArgs e)
        {
            List<string> AllIds = new List<string>();
            bool flag = true;
            foreach (Control txt in panelRight.Controls)
            {
                if (txt.GetType() == typeof(TextBox))
                {
                    if (txt.Name == "dynamicTextBox0")
                    {
                        dynamicId = txt.Text;
                        break;
                    }
                }
            }
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                AllIds.Add(Convert.ToString(dataGridView1.Rows[i].Cells[0].Value));
            }
            for (int Id = 0; Id < AllIds.Count; Id++)
            {
                if (dynamicId == AllIds[Id])
                {
                    flag = true;
                    break;
                }
                else
                {
                    flag = false;
                }
            }
            if (flag == true)
                updateData();
            else
                InsertData();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }

        private void InsertData()
        {
            DataTable dt = dataGridView1.DataSource as DataTable;
            dt.Rows.Add();
            int i = 0;
            foreach (Control txt in panelRight.Controls)
            {
                if (txt.GetType() == typeof(TextBox))
                {
                    dt.Rows[dt.Rows.Count - 1][i] = txt.Text;
                    i++;
                }
            }
            dataGridView1.DataSource = dt;
            UpdateCSVFile();
            MessageBox.Show("Data Inserted Successfully");
        }

        private void updateData()
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int i = 0;
                foreach (Control txt in panelRight.Controls)
                {
                    if (txt.GetType() == typeof(TextBox))
                    {
                        dataGridView1.Rows[0].Cells[i].Value = txt.Text;
                        i++;
                    }
                }
                UpdateCSVFile();
                dataGridView1.DataSource = ImportCSVData.BinddataGridView(lblPath.Text,comboBox1.SelectedItem.ToString());
                MessageBox.Show("Data Updated Successfully");
            }
        }

        private void UpdateCSVFile()
        {
            string csv = "";
            foreach (DataGridViewColumn dcol in dataGridView1.Columns)
            {
                if (dcol.Index == dataGridView1.ColumnCount - 1)
                    csv += dcol.HeaderText;
                else
                    csv += dcol.HeaderText + ',';
            }
            csv += "\r\n";
            for (int j = 0; j < dataGridView1.Rows.Count; j++)
            {
                for (int k = 0; k < dataGridView1.Rows[j].Cells.Count; k++)
                {
                    if (k == dataGridView1.Rows[j].Cells.Count - 1)
                        csv += dataGridView1.Rows[j].Cells[k].Value.ToString();
                    else
                        csv += dataGridView1.Rows[j].Cells[k].Value.ToString() + ',';
                }
                csv += "\r\n";
            }
            File.WriteAllText(lblPath.Text, csv);
        }

        private void buttonExportExcel_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = dataGridView1.DataSource as DataTable;
                CSVtoExcel.ExporttoExcel.ExportToExcel(dt);
            }
            catch (Exception ex)
            { MessageBox.Show(ex.ToString()); }
        }

        private void buttonFileBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    lblPath.Text = openFileDialog1.FileName;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void dataGridView1_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }
    }
}
