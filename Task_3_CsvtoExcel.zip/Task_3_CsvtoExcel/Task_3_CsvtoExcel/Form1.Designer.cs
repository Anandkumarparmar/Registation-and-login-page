﻿namespace Task_3_CsvtoExcel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.buttonFileBrowse = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPath = new System.Windows.Forms.Label();
            this.buttonFileLoad = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.panelCenter = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonExportExcel = new System.Windows.Forms.Button();
            this.panelRight = new System.Windows.Forms.Panel();
            this.buttonFileUpdate = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panelTop.SuspendLayout();
            this.panelCenter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panelRight.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panelTop.Controls.Add(this.buttonFileBrowse);
            this.panelTop.Controls.Add(this.comboBox1);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Controls.Add(this.lblPath);
            this.panelTop.Controls.Add(this.buttonFileLoad);
            this.panelTop.Controls.Add(this.buttonClose);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(901, 46);
            this.panelTop.TabIndex = 0;
            // 
            // buttonFileBrowse
            // 
            this.buttonFileBrowse.AutoSize = true;
            this.buttonFileBrowse.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonFileBrowse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonFileBrowse.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.buttonFileBrowse.FlatAppearance.BorderSize = 0;
            this.buttonFileBrowse.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonFileBrowse.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue;
            this.buttonFileBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFileBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFileBrowse.ForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.buttonFileBrowse.Location = new System.Drawing.Point(459, 2);
            this.buttonFileBrowse.Name = "buttonFileBrowse";
            this.buttonFileBrowse.Padding = new System.Windows.Forms.Padding(5);
            this.buttonFileBrowse.Size = new System.Drawing.Size(106, 40);
            this.buttonFileBrowse.TabIndex = 12;
            this.buttonFileBrowse.Text = "File Browse";
            this.buttonFileBrowse.UseVisualStyleBackColor = false;
            this.buttonFileBrowse.Click += new System.EventHandler(this.buttonFileBrowse_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.comboBox1.Items.AddRange(new object[] {
            ",",
            ".",
            "~",
            "!",
            "@",
            "#",
            "$",
            "%",
            "^",
            "&",
            "*"});
            this.comboBox1.Location = new System.Drawing.Point(614, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(67, 33);
            this.comboBox1.TabIndex = 11;
            this.comboBox1.Text = ",";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10);
            this.label1.Size = new System.Drawing.Size(66, 38);
            this.label1.TabIndex = 9;
            this.label1.Text = "Path :";
            // 
            // lblPath
            // 
            this.lblPath.AutoSize = true;
            this.lblPath.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblPath.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPath.ForeColor = System.Drawing.Color.White;
            this.lblPath.Location = new System.Drawing.Point(75, 2);
            this.lblPath.Name = "lblPath";
            this.lblPath.Padding = new System.Windows.Forms.Padding(10);
            this.lblPath.Size = new System.Drawing.Size(20, 38);
            this.lblPath.TabIndex = 10;
            // 
            // buttonFileLoad
            // 
            this.buttonFileLoad.AutoSize = true;
            this.buttonFileLoad.BackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonFileLoad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonFileLoad.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.buttonFileLoad.FlatAppearance.BorderSize = 0;
            this.buttonFileLoad.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonFileLoad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue;
            this.buttonFileLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFileLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFileLoad.ForeColor = System.Drawing.Color.LightGoldenrodYellow;
            this.buttonFileLoad.Location = new System.Drawing.Point(702, 3);
            this.buttonFileLoad.Name = "buttonFileLoad";
            this.buttonFileLoad.Padding = new System.Windows.Forms.Padding(5);
            this.buttonFileLoad.Size = new System.Drawing.Size(135, 40);
            this.buttonFileLoad.TabIndex = 8;
            this.buttonFileLoad.Text = "File Load";
            this.buttonFileLoad.UseVisualStyleBackColor = false;
            this.buttonFileLoad.Click += new System.EventHandler(this.buttonFileLoad_Click);
            // 
            // buttonClose
            // 
            this.buttonClose.BackColor = System.Drawing.Color.DarkRed;
            this.buttonClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonClose.FlatAppearance.BorderSize = 0;
            this.buttonClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonClose.Location = new System.Drawing.Point(843, 2);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(58, 40);
            this.buttonClose.TabIndex = 7;
            this.buttonClose.Text = "X";
            this.buttonClose.UseVisualStyleBackColor = false;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // panelCenter
            // 
            this.panelCenter.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panelCenter.Controls.Add(this.dataGridView1);
            this.panelCenter.Controls.Add(this.buttonExportExcel);
            this.panelCenter.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelCenter.Location = new System.Drawing.Point(0, 46);
            this.panelCenter.Name = "panelCenter";
            this.panelCenter.Size = new System.Drawing.Size(565, 333);
            this.panelCenter.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.GridColor = System.Drawing.Color.Teal;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(5);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(565, 286);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.Tag = "";
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseClick);
            this.dataGridView1.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellMouseEnter);
            // 
            // buttonExportExcel
            // 
            this.buttonExportExcel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonExportExcel.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.buttonExportExcel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExportExcel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonExportExcel.FlatAppearance.BorderColor = System.Drawing.Color.SteelBlue;
            this.buttonExportExcel.FlatAppearance.BorderSize = 0;
            this.buttonExportExcel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonExportExcel.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonExportExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExportExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExportExcel.ForeColor = System.Drawing.Color.LightYellow;
            this.buttonExportExcel.Location = new System.Drawing.Point(0, 286);
            this.buttonExportExcel.Name = "buttonExportExcel";
            this.buttonExportExcel.Size = new System.Drawing.Size(565, 47);
            this.buttonExportExcel.TabIndex = 6;
            this.buttonExportExcel.Text = "Export To Excel";
            this.buttonExportExcel.UseVisualStyleBackColor = false;
            this.buttonExportExcel.Visible = false;
            this.buttonExportExcel.Click += new System.EventHandler(this.buttonExportExcel_Click);
            // 
            // panelRight
            // 
            this.panelRight.AutoScroll = true;
            this.panelRight.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelRight.Controls.Add(this.buttonFileUpdate);
            this.panelRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelRight.Location = new System.Drawing.Point(563, 46);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(338, 333);
            this.panelRight.TabIndex = 2;
            this.panelRight.Visible = false;
            // 
            // buttonFileUpdate
            // 
            this.buttonFileUpdate.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonFileUpdate.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonFileUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonFileUpdate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonFileUpdate.FlatAppearance.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.buttonFileUpdate.FlatAppearance.BorderSize = 0;
            this.buttonFileUpdate.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonFileUpdate.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.HotTrack;
            this.buttonFileUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonFileUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFileUpdate.ForeColor = System.Drawing.Color.White;
            this.buttonFileUpdate.Location = new System.Drawing.Point(0, 286);
            this.buttonFileUpdate.Name = "buttonFileUpdate";
            this.buttonFileUpdate.Size = new System.Drawing.Size(338, 47);
            this.buttonFileUpdate.TabIndex = 5;
            this.buttonFileUpdate.Text = "Update Data";
            this.buttonFileUpdate.UseVisualStyleBackColor = false;
            this.buttonFileUpdate.Click += new System.EventHandler(this.buttonFileUpdate_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(901, 379);
            this.Controls.Add(this.panelRight);
            this.Controls.Add(this.panelCenter);
            this.Controls.Add(this.panelTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelCenter.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panelRight.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelCenter;
        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPath;
        private System.Windows.Forms.Button buttonFileLoad;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Button buttonExportExcel;
        private System.Windows.Forms.Button buttonFileUpdate;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button buttonFileBrowse;
    }
}

